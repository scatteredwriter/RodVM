#ifndef _LCD_H_
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/mman.h>
#define _LCD_H_
#endif

int lcd_rbg(unsigned int rgb);
int lcd_5rbg(int type);