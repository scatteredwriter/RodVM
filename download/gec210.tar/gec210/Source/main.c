#include "lcd.h"

int main()
{
    int i = 20;
    while (i--)
    {
        lcd_5rbg(i % 2);
        sleep(3);
    }
    return 0;
}