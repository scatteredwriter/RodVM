#include "lcd.h"

int lcd_rbg(unsigned int rgb)
{
    int file = open("/dev/fb0", O_RDWR);
    int buff[800 * 480] = {0};
    int i = 0;
    for (; i < 800 * 480; i++)
    {
        buff[i] = rgb;
    }
    write(file, buff, 800 * 480 * 4);
    close(file);
    return 0;
}

// SYNOPSIS
//        #include <sys/mman.h>

//        void *mmap(void *addr, size_t length, int prot, int flags,
//                   int fd, off_t offset);
//        int munmap(void *addr, size_t length);
//
//    MAP_SHARED
//           Share this mapping.  Updates to the mapping are visible to other
//           processes  that  map  this  file, and are carried through to the
//           underlying file.  (To precisely control when updates are carried
//           through to the underlying file requires the use of msync(2).)

//    MAP_PRIVATE
//           Create  a private copy-on-write mapping.  Updates to the mapping
//           are not visible to other processes mapping the  same  file,  and
//           are  not carried through to the underlying file.  It is unspeci‐
//           fied whether changes made to the file after the mmap() call  are
//           visible in the mapped region.
int lcd_5rbg(int type)
{
    int file = open("/dev/fb0", O_RDWR);
    int *fb = mmap(NULL, 800 * 480 * 4, PROT_READ | PROT_WRITE, MAP_SHARED, file, 0);
    int i = 0;
    if (type == 0)
        for (; i < 800 * 480; i++)
        {
            if ((i % 800) < 800 / 5 * 1)
                fb[i] = 0xE2004E;
            else if ((i % 800) < 800 / 5 * 2)
                fb[i] = 0x00ADCB;
            else if ((i % 800) < 800 / 5 * 3)
                fb[i] = 0x008574;
            else if ((i % 800) < 800 / 5 * 4)
                fb[i] = 0xFFB600;
            else if ((i % 800) < 800)
                fb[i] = 0xA3D7D2;
        }
    else if (type == 1)
    {
        for (; i < 800 * 480; i++)
        {
            if (i < 800 * 480 / 5 * 1)
                fb[i] = 0xE2004E;
            else if (i < 800 * 480 / 5 * 2)
                fb[i] = 0x00ADCB;
            else if (i < 800 * 480 / 5 * 3)
                fb[i] = 0x008574;
            else if (i < 800 * 480 / 5 * 4)
                fb[i] = 0xFFB600;
            else if (i < 800 * 480)
                fb[i] = 0xA3D7D2;
        }
    }
    munmap(fb, 800 * 480 * 4);
    close(file);
    return 0;
}